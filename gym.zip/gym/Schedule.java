import java.util.ArrayList; 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.security.cert.CertPath;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class Schedule {
    private String day;         // Day of the schedule
    private String time;        // Time of the schedule
    private String activity;    // Activity of the schedule
    private String shift;       // Shift of the schedule

    // Default constructor
    public Schedule() {
        this.day = day;
        this.time = time;
        this.activity = activity;
        this.shift = shift;
    }
    // Getters and setters
    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

   public static JPanel showSchedulePanel() {
    JPanel schedulePanel = new JPanel(new BorderLayout());
    schedulePanel.setBackground(Color.LIGHT_GRAY);
    String[] columnNames = { "Member_id","Day", "Timing","Schedule","Game"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable scheduleTable = new JTable(tableModel);

    // Add table header and table to the panel
    schedulePanel.add(new JScrollPane(scheduleTable), BorderLayout.CENTER);

    try {
        //Database connection and query
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
        String query = "SELECT * FROM schedules";
        PreparedStatement pst = con.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        // Populate table with data from the database
        while (rs.next()) {
            int member_id = rs.getInt("member_id");
            String day= rs.getString("day");
            String time = rs.getString("time");
            String shift = rs.getString("shift");
            String activity= rs.getString("activity");
            tableModel.addRow(new Object[]{member_id,day,time, shift,activity});
        }

        // Close database resources
        rs.close();
        pst.close();
        con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(schedulePanel, "Error loading schedule data.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    return schedulePanel;
}


    // Method to display schedule details
    public void displayDetails() {
        System.out.println("Schedule Details:");
        System.out.println("Day: " + day);
        System.out.println("Time: " + time);
        System.out.println("Activity: " + activity);
        System.out.println("Shift: " + shift); 
    }
        public static void insertScheduleIntoDatabase(int memberId, String memb_name, String day, String time, String activity, String shift)throws Exception {
        String jdbcURL = "jdbc:mysql://localhost:3306/test_schema?useSSL=false";
        String username = "root";
        String password = "1214";
    
        // Correct SQL query (ensure columns match the database table schema)
        String sql = "INSERT INTO schedules (member_id, day, time, activity, shift) VALUES (?, ?, ?, ?, ?)";
    
        try (Connection conn = DriverManager.getConnection(jdbcURL, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            // Set the parameters in the correct order
            stmt.setInt(1, memberId);   // member_id
            stmt.setString(2, day);     // day
            stmt.setString(3, time);    // time
            stmt.setString(4, activity);// activity
            stmt.setString(5, shift);   // shift
            
            // Execute the INSERT statement
            int rowsInserted = stmt.executeUpdate();
    
            // Optional: Confirm that rows were inserted
            if (rowsInserted > 0) {
                System.out.println("Schedule successfully added to the database.");
            } else {
                System.out.println("No rows were inserted. Please check your query.");
            }
    
        } catch (SQLException ex) {
            // Handle SQL exceptions
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static JPanel crateschedulePanel() {
        String[] sched = {"Morning", "Evening", "Night"};
        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    
        // Create the panel with GridBagLayout for better control over positioning
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Add space between components
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("Arial", Font.BOLD, 25); // Font for labels
    
        // Components for Schedule Panel
        JTextField schedtime = new JTextField(20);
        schedtime.setBackground(Color.black);
        schedtime.setForeground(Color.white);
        schedtime.setFont(new Font("Arial", Font.PLAIN, 20));
    
        JTextField schedactivity = new JTextField(20);
        schedactivity.setBackground(Color.black);
        schedactivity.setForeground(Color.white);
        schedactivity.setFont(new Font("Arial", Font.PLAIN, 20));
    
        JComboBox<String> schedule = new JComboBox<>(sched);
        schedule.setBackground(Color.black);
        schedule.setForeground(Color.white);
        schedule.setFont(new Font("Arial", Font.PLAIN, 20));
    
        JComboBox<String> day2 = new JComboBox<>(days);
        day2.setBackground(Color.black);
        day2.setForeground(Color.white);
        day2.setFont(new Font("Arial", Font.PLAIN, 20));
    
        // Member dropdown
        JComboBox<String> membDropdown = new JComboBox<>();
        membDropdown.setFont(new Font("Arial", Font.PLAIN, 20));
        membDropdown.setBackground(Color.black);
        membDropdown.setForeground(Color.white);
    
        // Populate the member dropdown with data from the database
        try {
            // Database connection
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
            String query = "SELECT memb_id, name,email FROM members"; // Adjust query to select member ID and name
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            // Populate the dropdown
            while (rs.next()) {
                int memb_id = rs.getInt("memb_id");
                String memb_name = rs.getString("name");
                String memb_email = rs.getString("email");

                membDropdown.addItem(memb_id + " | " + memb_name+" | "+ memb_email);
            }
    
            // Close resources
            rs.close();
            pst.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching members from the database: " + ex.getMessage());
        }
    
        JButton addsched = new JButton("Add a schedule");
        JButton avlblschedule = new JButton("View Member's Schedule");
    
        // Style buttons
        addsched.setForeground(Color.white);
        addsched.setBackground(Color.black);  // Green color for "Add a schedule"
        addsched.setFont(new Font("Arial", Font.BOLD, 20));
    
        avlblschedule.setForeground(Color.white);
        avlblschedule.setBackground(Color.black);  // Blue color for "View Member's Schedule"
        avlblschedule.setFont(new Font("Arial", Font.BOLD, 20));
    
        JPanel schPanel = new JPanel(new GridBagLayout()) {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
    
                // Load the background image
                Image backgroundImage = new ImageIcon(Member.class.getResource("room.jpg")).getImage();
    
                // Draw the image to fit the entire panel
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        schPanel.setOpaque(false);
        schPanel.setBackground(new Color(255, 218, 185));
    
        // Add member dropdown first
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel membDropdownLabel = new JLabel("Select a Member from the database:");
        membDropdownLabel.setForeground(Color.white);
        membDropdownLabel.setFont(labelFont);
        schPanel.add(membDropdownLabel, gbc);
    
        gbc.gridx = 1;
        schPanel.add(membDropdown, gbc);
    
        // Add schedule fields below
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel schedTimeLabel = new JLabel("Enter the timing of the gym:");
        schedTimeLabel.setForeground(Color.WHITE);
        schPanel.add(schedTimeLabel, gbc);
        schedTimeLabel.setFont(labelFont);
    
        gbc.gridx = 1;
        schPanel.add(schedtime, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel schedActivityLabel = new JLabel("Enter the activity for the schedule:");
        schedActivityLabel.setForeground(Color.white);
        schPanel.add(schedActivityLabel, gbc);
        schedActivityLabel.setFont(labelFont);
    
        gbc.gridx = 1;
        schPanel.add(schedactivity, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel daysLabel = new JLabel("Enter the working day(s):");
        daysLabel.setForeground(Color.white);
        schPanel.add(daysLabel, gbc);
        daysLabel.setFont(labelFont);
    
        gbc.gridx = 1;
        schPanel.add(day2, gbc);
    
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel scheduleLabel = new JLabel("Enter the schedule timing:");
        scheduleLabel.setForeground(Color.white);
        schPanel.add(scheduleLabel, gbc);
        scheduleLabel.setFont(labelFont);
    
        gbc.gridx = 1;
        schPanel.add(schedule, gbc);
    
        // Add buttons to the panel
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;  // Make buttons span across both columns
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false);  // Set the background of the button panel transparent
        buttonPanel.add(addsched);
        buttonPanel.add(avlblschedule);
        schPanel.add(buttonPanel, gbc);
    
        // Add listeners
        addsched.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get values from the form fields
                    String selectedMember = (String) membDropdown.getSelectedItem();
                    String activity = schedactivity.getText();
                    String day = (String) day2.getSelectedItem();
                    String time = schedtime.getText();
                    String shift = (String) schedule.getSelectedItem();
    
                    // Validate the inputs
                    if (selectedMember == null || activity.isEmpty() || time.isEmpty() || day == null || shift == null) {
                        JOptionPane.showMessageDialog(null, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
    
                    String[] memberDetails = selectedMember.split("\\|");
                    int memberId = Integer.parseInt(memberDetails[0].trim());
                    String memberName = memberDetails[1].trim();
    
                    // Create a new Schedule object
                    Member m2 = new Member();
                    m2.setId(memberId);
                    m2.setName(memberName);
                    Schedule s1 = new Schedule();
                    s1.setDay(day);
                    s1.setActivity(activity);
                    s1.setShift(shift);
                    s1.setTime(time);
                    m2.assignSchedule(s1);
                    m2.addmember();
    
                    // Optional: Add the schedule to the database
                    Schedule.insertScheduleIntoDatabase(memberId, memberName, day, time, activity, shift);
                    
                    // Show success message in GUI
                    JOptionPane.showMessageDialog(null, "Schedule added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    
                } catch (Exception ex) {
                    ex.printStackTrace();
                    // Handle exceptions and show error message
                    JOptionPane.showMessageDialog(null, "Error adding schedule: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    
        avlblschedule.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new JFrame to display the schedule
                JFrame scheduleFrame = new JFrame("Available Schedules");
                scheduleFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                scheduleFrame.setSize(600, 400);
    
                // Get the schedule panel and add it to the JFrame
                JPanel schedulePanel = Schedule.showSchedulePanel();
                scheduleFrame.add(schedulePanel);
    
                // Set the frame's location to the center of the screen and make it visible
                scheduleFrame.setLocationRelativeTo(null);
                scheduleFrame.setVisible(true);
            }
        });
    
        return schPanel;
    }}
    