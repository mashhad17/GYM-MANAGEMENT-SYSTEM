import java.util.ArrayList; 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Trainer {
    private String trainermaster;
    private  String trainerName;
    private String trainerContact;
    private  String trainerEmail;
    private Member member1;
    
    public Trainer() {
       this.trainerContact=trainerContact;
       this.trainerEmail=trainerEmail;
       this.trainermaster=trainermaster;
       this.trainerName=trainerName;
}
   
    // Getter and Setter for trainerGender
public String getTrainermaster() {
    return trainermaster;
}

public void setTrainermaster(String trainermaster) {
    this.trainermaster = trainermaster;
}
// Getter and Setter for trainerName
public String getTrainerName() {
    return trainerName;
}

public void setTrainerName(String trainerName) {
    this.trainerName = trainerName;
}

// Getter and Setter for trainerContact
public String getTrainerContact() {
    return trainerContact;
}

public void setTrainerContact(String trainerContact) {
    this.trainerContact= trainerContact;
}

// Getter and Setter for trainerEmail
public String getTrainerEmail() {
    return trainerEmail;
}

public void setTrainerEmail(String trainerEmail) {
    this.trainerEmail=trainerEmail;
}
// Getter for member1
public Member getMember1() {
    return member1;
}

// Setter for member1
public void setMember1(Member member1) {
    this.member1 = member1;
}


    public void assignMember(Member member1){
        this.member1=member1;
        System.out.println("Trainer name is :"+trainerName);
        System.out.println("Member name is :"+member1.getName());
        System.out.println("Member email is :"+member1.getEmail());
    }
    public void addtrainer(){
        System.out.println("Name of the trainer  is :"+trainerName);
        System.out.println("Email of the trainer is :"+trainerEmail);
        System.out.println("Contact of the trainer is :"+trainerContact);
        System.out.println("Specialization/expertize of the trainer is :"+trainermaster);
    }
      public static JPanel showtrainerPanel() {
    JPanel trainerPanel = new JPanel(new BorderLayout());
    trainerPanel.setBackground(Color.LIGHT_GRAY);
    String[] columnNames = { "Trainer Name","Trainer- Id", "Contact","Expert"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable trainerTable = new JTable(tableModel);

    // Add table header and table to the panel
    trainerPanel.add(new JScrollPane(trainerTable), BorderLayout.CENTER);

    try {
        //Database connection and query
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
        String query = "SELECT * FROM trainers";
        PreparedStatement pst = con.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        // Populate table with data from the database
        while (rs.next()) {
            String name = rs.getString("name");
            String email = rs.getString("email");
            String contact = rs.getString("contact");
            String special= rs.getString("special");
            tableModel.addRow(new Object[]{name,email,contact,special});
        }

        // Close database resources
        rs.close();
        pst.close();
        con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(trainerPanel, "Error loading trainer data.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    return trainerPanel;
}
    public static void insertTrainerIntoDatabase(String name, String email, String contact, String special) throws Exception {
        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/test_schema?useSSL=false";
        String username = "root";
        String password = "1214";

        // SQL query
        String sql = "INSERT INTO trainers (name, email, contact, special) VALUES (?, ?, ?, ?)";

        // Connect to the database and execute the query
        try (Connection conn = DriverManager.getConnection(jdbcURL, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Set the parameters
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, contact);
            stmt.setString(4, special);

            // Execute the update
            stmt.executeUpdate();}

            catch (SQLException ex) {
                ex.printStackTrace();
                throw new Exception("Database operation failed: " + ex.getMessage());}   
    }
    public static void deleteTrainerFromDatabase(String email) throws Exception {
        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/test_schema?useSSL=false";
        String username = "root";
        String password = "1214";

        // SQL query to delete trainer based on email
        String sql = "DELETE FROM trainers WHERE email = ?";

        // Connect to the database and execute the query
        try (Connection conn = DriverManager.getConnection(jdbcURL, username, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the parameter (trainer email to delete)
            stmt.setString(1, email);

            // Execute the delete query
            int rowsAffected = stmt.executeUpdate();}

            catch (SQLException ex) {
                ex.printStackTrace();
                throw new Exception("Database operation failed: " + ex.getMessage());} 
    }

    public static JPanel showAssignedMembersPanel() {
        JPanel assignedMembersPanel = new JPanel(new BorderLayout());
        assignedMembersPanel.setBackground(Color.LIGHT_GRAY);
    
        // Define column names for the table
        String[] columnNames = { "Trainer Name", "Member Name", "Member Email", "Member Contact" };
    
        // Create a DefaultTableModel to populate the JTable
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
         JTable assignedMembersTable = new JTable(tableModel);
    
        // Add table header and table to the panel
        assignedMembersPanel.add(new JScrollPane(assignedMembersTable), BorderLayout.CENTER);
    
        try {
            // Database connection details
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
    
            // SQL query to fetch assigned members with their trainers
            String query = "SELECT t.name AS trainer_name, m.name AS member_name, m.email AS member_email, m.contact AS member_contact " +
                           "FROM trainer_member tm " +
                           "JOIN trainers t ON tm.trainer_id = t.trainer_id " +
                           "JOIN members m ON tm.member_id = m.memb_id";
    
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
    
            // Populate the table with data from the query
            while (rs.next()) {
                String trainerName = rs.getString("trainer_name");
                String memberName = rs.getString("member_name");
                String memberEmail = rs.getString("member_email");
                String memberContact = rs.getString("member_contact");
    
                // Add each row to the table
                tableModel.addRow(new Object[] { trainerName, memberName, memberEmail, memberContact });
            }
    
            // Close database resources
            rs.close();
            pst.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(assignedMembersPanel, "Error loading assigned members data.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    
        return assignedMembersPanel;
    }
    
     
    public static void assignTrainerToMemberInDatabase(Trainer trainer, Member member) throws Exception {
        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/test_schema?useSSL=false";
        String username = "root";
        String password = "1214";
    
        // SQL query to insert into the trainer_member table
        String sql = "INSERT INTO trainer_member (trainer_id, member_id) VALUES (?, ?)";
        
        // Fetch the trainer ID based on the trainer's name or email
        int trainerId = getTrainerIdByName(trainer.getTrainerName()); // Implement this method
            
                if (trainerId == -1) {
                    throw new Exception("Trainer not found in the database.");
                }
                try (Connection conn = DriverManager.getConnection(jdbcURL, username, password);
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, trainerId); // Set the trainer ID
                    stmt.setInt(2, member.getId()); // Set the member ID
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw new Exception("Error assigning trainer to member: " + e.getMessage());
                }
            }
        
            private static int getTrainerIdByName(String trainerName) {
                String jdbcURL = "jdbc:mysql://localhost:3306/test_schema?useSSL=false";
                String username = "root";
                String password = "1214";
                String sql = "SELECT trainer_id FROM trainers WHERE name = ?";

                try (Connection conn = DriverManager.getConnection(jdbcURL, username, password);
                    PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, trainerName);
                    ResultSet rs = stmt.executeQuery();
            
                    if (rs.next()) {
                        return rs.getInt("trainer_id"); // Return the trainer ID
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return -1; // Return -1 if the trainer is not found
            }
            public static Member getMemberById(int memberId) {
                // Database connection details
                String jdbcURL = "jdbc:mysql://localhost:3306/test_schema?useSSL=false";
                String username = "root";
                String password = "1214";
            
                String sql = "SELECT * FROM members WHERE memb_id = ?";
                try (Connection conn = DriverManager.getConnection(jdbcURL, username, password);
                     PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setInt(1, memberId);
                    ResultSet rs = stmt.executeQuery();
            
                    if (rs.next()) {
                        Member member = new Member();
                        member.setId(rs.getInt("memb_id"));
                        member.setName(rs.getString("name"));
                        member.setEmail(rs.getString("email"));
                        member.setContact(rs.getString("contact"));
                        // Set other member attributes if needed
                        return member;
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return null; // Return null if no member found
            }
             public static JPanel createTrainerPanel() {
                //Create the panel with GridBagLayout for better control
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.insets = new Insets(10, 10, 10, 10);  // Add space between components
                gbc.anchor = GridBagConstraints.WEST;      
                Font labelFont = new Font("Arial", Font.BOLD, 25); //

              
                JButton assignTrainerButton = new JButton("Assign Member");
                JButton avlbltrainer = new JButton("Available Trainers List");
                JButton showAssignedMembersButton = new JButton("Show Assigned Members");
        
                // Style buttons
                assignTrainerButton.setBackground(Color.black);
                assignTrainerButton.setForeground(Color.white);  // Green color for "Assign Member"
                assignTrainerButton.setFont(new Font("Arial", Font.BOLD, 20));
        
                avlbltrainer.setBackground(Color.black);
                avlbltrainer.setForeground(Color.white);  // Blue color for "Available Trainers List"
                avlbltrainer.setFont(new Font("Arial", Font.BOLD, 20));
        
                showAssignedMembersButton.setBackground(Color.black);
                showAssignedMembersButton.setForeground(Color.white);  // Orange-Red color for "Show Assigned Members"
                showAssignedMembersButton.setFont(new Font("Arial", Font.BOLD, 20));
                // Add components to the form panel using GridBagLayout
              // Add components to the form panel using GridBagLayout
              JPanel jtpanel = new JPanel(new GridBagLayout()) {
                @Override
                public void paintComponent(Graphics g) {
                        super.paintComponent(g);
                
                        // Load the background image
                        Image backgroundImage = new ImageIcon(Member.class.getResource("room.jpg")).getImage();
                
                        // Draw the image to fit the entire panel
                        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                    }
                };
              /* */ 
                jtpanel.setOpaque(false);
                  jtpanel.setBackground(new Color(255, 218, 185)); 

                  gbc.gridx = 0;
                  gbc.gridy = 0;

JComboBox<String> trainerDropdown = new JComboBox<>();
trainerDropdown.setFont(new Font("Arial", Font.PLAIN, 20));
trainerDropdown.setBackground(Color.black);
trainerDropdown.setForeground(Color.white);

// Populate the trainer dropdown with data from the database
try {
    // Database connection
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
    String query = "SELECT name, email, special FROM trainers"; // Replace with your table and column names
    PreparedStatement pst = con.prepareStatement(query);
    ResultSet rs = pst.executeQuery();
    // Populate the dropdown
    while (rs.next()) {
        String name = rs.getString("name");
        String contact = rs.getString("email");
        String special = rs.getString("special");
        trainerDropdown.addItem(name + " | " + contact + " | " + special);
    }
    // Close resources
    rs.close();
    pst.close();
    con.close();
} catch (SQLException ex) {
    ex.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error fetching trainers from the database: " + ex.getMessage());
}
                // Add Trainer Dropdown above the button panel
gbc.gridx = 0;
gbc.gridy = 4; // Place dropdown label and combo box in row 4
JLabel trainerDropdownLabel = new JLabel("Select a trainer from the database:");
trainerDropdownLabel.setForeground(Color.white);
trainerDropdownLabel.setFont(labelFont);
jtpanel.add(trainerDropdownLabel, gbc);

gbc.gridx = 1;
jtpanel.add(trainerDropdown, gbc);

// Add Button Panel below the dropdown
gbc.gridx = 0;
gbc.gridy = 5; // Move button panel to row 5
gbc.gridwidth = 2; // Make the button panel span both columns (full width)
JPanel buttonPanel = new JPanel(new FlowLayout());
buttonPanel.setOpaque(false); // Set the background of the button panel transparent
buttonPanel.add(assignTrainerButton);
buttonPanel.add(avlbltrainer);
buttonPanel.add(showAssignedMembersButton);

// Add button panel to the main panel
jtpanel.add(buttonPanel, gbc);
    
        // Add ActionListener for the button
        showAssignedMembersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame assignedFrame = new JFrame();
                assignedFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                assignedFrame.setSize(600, 400);
        
                // Call the method to show assigned members
                JPanel assignedMembersPanel = Trainer.showAssignedMembersPanel();
                assignedFrame.add(assignedMembersPanel);
        
                assignedFrame.setVisible(true);
            }
        });
        
        avlbltrainer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                JFrame trainFrame = new JFrame();
                trainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                trainFrame.setSize(600,400);

                JPanel trainerPanel = Trainer.showtrainerPanel();
                trainFrame.add(trainerPanel);

                trainFrame.setVisible(true);
            }
        });
        // Add ActionListener for the trainer dropdown
// Add ActionListener for the trainer dropdown
trainerDropdown.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        if (trainerDropdown.getSelectedItem() != null) {
            // Get the selected trainer details
            String selectedTrainer = trainerDropdown.getSelectedItem().toString();
            JOptionPane.showMessageDialog(null, 
                "Trainer selected: " + selectedTrainer, 
                "Trainer Selection", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
});

assignTrainerButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Ensure a trainer is selected
        if (trainerDropdown.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Please select a trainer first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Get the selected trainer's details
        String selectedTrainer = trainerDropdown.getSelectedItem().toString();

        // Ask for Member ID through a dialog box
        String memberIdStr = JOptionPane.showInputDialog(null, 
                "Enter the Member ID to assign to the trainer: " + selectedTrainer,
                "Assign Member to Trainer",
                JOptionPane.QUESTION_MESSAGE);

        // Handle empty or canceled input
        if (memberIdStr == null || memberIdStr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Member ID cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int memberId = Integer.parseInt(memberIdStr); // Parse Member ID

            // Assuming you have a method to fetch a member by ID
            Member member = Trainer.getMemberById(memberId); // Implement this method to fetch member details

            if (member != null) {
                // Parse trainer details from the dropdown selection (split by "|")
                String[] trainerDetails = selectedTrainer.split("\\|");
                String trainerName = trainerDetails[0].trim(); // Trainer Name

                // Create a Trainer object and assign the member
                Trainer trainer = new Trainer();
                trainer.setTrainerName(trainerName);
                // Additional trainer details can also be set if needed

                // Assign the trainer to the member
                trainer.assignMember(member);

                // Optionally, save this relationship in the database
                Trainer.assignTrainerToMemberInDatabase(trainer, member);

                JOptionPane.showMessageDialog(null, 
                        "Trainer " + trainerName + " has been assigned to Member ID " + memberId + " successfully!", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No member found with ID: " + memberId, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid Member ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error assigning trainer: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});

return jtpanel;
}    

}