import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList; 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Member  {
    private Schedule schedule;
    private String membershipType;
    private int memb_id;
    private  String name;
    private String contact;
    private  String email;
    
    public Member() {
        this.memb_id = memb_id;
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.membershipType = membershipType;
        this.schedule = new Schedule();
    }
    
    public void setSchedule(Schedule schedule) {
        this.schedule= schedule;
    }
    
    public Schedule getSchedule() {
        return schedule;
    }
    public String getMembershipType() {
        return membershipType;
    }
    public void assignSchedule(Schedule schedule){
        this.schedule=schedule;
    }
    public int getId() { return memb_id; }
    public void setId(int memb_id) { this.memb_id = memb_id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public void addmember(){
        System.out.println("Id  of the member is :"+memb_id);
        System.out.println("Name of the member is :"+name);
        System.out.println("Contact of the member is :"+contact);
        System.out.println("Email of the member is :"+email);
}

public static JPanel showMemberPanel() {
    JPanel memberPanel = new JPanel(new BorderLayout());
    memberPanel.setBackground(Color.LIGHT_GRAY);
    String[] columnNames = { "Member Id","Member Name","Member Email", " Member Contact","Gender"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable memberTable = new JTable(tableModel);

    // Add table header and table to the panel
    memberPanel.add(new JScrollPane(memberTable), BorderLayout.CENTER);
      
    try {

        //Database connection and query
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
        String query = "SELECT * FROM members";
        PreparedStatement pst = con.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        // Populate table with data from the database
        while (rs.next()) {
            int memb_id = rs.getInt("memb_id");
            String name = rs.getString("name");
            String email = rs.getString("email");
            String contact= rs.getString("contact");
            String role= rs.getString("role");
            tableModel.addRow(new Object[]{memb_id,name,email,contact,role});
        }

        // Close database resources
        rs.close();
        pst.close();
        con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(memberPanel, "Error loading trainer data.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    return memberPanel;
}
        public static void insertMemberIntoDatabase(String name, String email, String contact, String role,int memb_id) throws Exception {
            // Database connection details
            String jdbcURL = "jdbc:mysql://localhost:3306/test_schema?useSSL=false";
            String username = "root";
            String password = "1214";
            // SQL query
            String sql = "INSERT INTO members (name, email, contact, role,memb_id) VALUES (?, ?, ?, ?,?)";
    
            // Connect to the database and execute the query
            try (Connection conn = DriverManager.getConnection(jdbcURL, username, password);
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                // Set the parameters
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, contact);
                stmt.setString(4, role);
                stmt.setInt(5, memb_id);
    
                // Execute the update
                stmt.executeUpdate();
            }
            catch (SQLException ex) {
                ex.printStackTrace();
                throw new Exception("Database operation failed: " + ex.getMessage());
            }
        }
        public static JPanel createAdminNTrainerPanel() {
            // Roles for Admin
        String[] roles = {"Male", "Female", "None"};
        String[] special = {"Body-Building", "Cardio", "Weight-lifting"};

        // Create the panel with GridBagLayout for precise positioning
    // Create a panel with a custom background
   // Light gray background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Space between components
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("Arial", Font.BOLD, 25); //
        // Components for Admin Panel
        JTextField adminName = new JTextField(20);
        adminName.setBackground(Color.black);
        adminName.setForeground(Color.white);
            adminName.setFont(new Font("Arial", Font.PLAIN, 20));

        JTextField adminEmail = new JTextField(20);
            adminEmail.setBackground(Color.black);
        adminEmail.setForeground(Color.white);
        adminEmail.setFont(new Font("Arial", Font.PLAIN, 20));

        JTextField adminContact = new JTextField(20);
        adminContact.setBackground(Color.black);
        adminContact.setForeground(Color.white);
        adminContact.setFont(new Font("Arial", Font.PLAIN, 20));

        JTextField trname = new JTextField(20);
        trname.setBackground(Color.black);
        trname.setForeground(Color.white);
        trname.setFont(new Font("Arial", Font.PLAIN, 20));

        JTextField trEmail = new JTextField(20);
        trEmail.setBackground(Color.black);
        trEmail.setForeground(Color.white);
        trEmail.setFont(new Font("Arial", Font.PLAIN, 20));

        JTextField idfield = new JTextField(20);
        idfield.setBackground(Color.black);
        idfield.setForeground(Color.white);
        idfield.setFont(new Font("Arial", Font.PLAIN, 20));

        JTextField trContact = new JTextField(20);
        trContact.setBackground(Color.black);
        trContact.setForeground(Color.white);
        trContact.setFont(new Font("Arial", Font.PLAIN, 20));


        JButton avlblmember = new JButton("Registered members list");
        JButton jmembadd = new JButton("Add member");
        JButton jtraineradd = new JButton("Add trainer");
        JButton jtrainerdel = new JButton("Remove trainer");

        JComboBox<String> adminRole = new JComboBox<>(roles);
        adminRole.setBackground(Color.black);
        adminRole.setForeground(Color.white);
        adminRole.setFont(new Font("Arial", Font.PLAIN, 20));
        JComboBox<String> trgender = new JComboBox<>(special);
        trgender.setBackground(Color.black);
        trgender.setForeground(Color.white);
        trgender.setFont(new Font("Arial", Font.PLAIN, 20));
        // Style buttons
        jmembadd.setForeground(Color.white);
        jmembadd.setBackground(Color.black// Light Sky Blue
        );  // Green color for "Add member"
        jmembadd.setFont(new Font("Arial", Font.BOLD, 20));

        jtraineradd.setForeground(Color.white);
        jtraineradd.setBackground(Color.black// Light Sky Blue
        );  // Blue color for "Add trainer"
        jtraineradd.setFont(new Font("Arial", Font.BOLD, 20));

        jtrainerdel.setForeground(Color.white);
        jtrainerdel.setBackground(Color.black// Light Sky Blue
        );  // Red color for "Remove trainer"
        jtrainerdel.setFont(new Font("Arial", Font.BOLD, 20));

        avlblmember.setForeground(Color.white);
        avlblmember.setBackground(Color.black // Light Sky Blue
        );  // Orange color
        avlblmember.setFont(new Font("Arial", Font.BOLD, 20));
        // Admin Name Section
       // Admin Name Section
       JPanel adminPanel = new JPanel(new GridBagLayout()) {
        @Override
        public void paintComponent(Graphics g) {
                super.paintComponent(g);
        
                // Load the background image
                Image backgroundImage = new ImageIcon(Member.class.getResource("room.jpg")).getImage();
        
                // Draw the image to fit the entire panel
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
      /* */ 
        adminPanel.setOpaque(false);
          adminPanel.setBackground(new Color(255, 218, 185)); 
gbc.gridx = 0;
gbc.gridy = 0;
JLabel nameLabel = new JLabel("Enter name of the Member:");
nameLabel.setForeground(Color.white);
adminPanel.add(nameLabel, gbc);
nameLabel.setFont(labelFont);
gbc.gridx = 1;
adminPanel.add(adminName, gbc);

// Admin ID Section
gbc.gridx = 0;
gbc.gridy = 1;
JLabel idLabel = new JLabel("Enter ID of the Member:");
idLabel.setForeground(Color.white);
adminPanel.add(idLabel, gbc);
idLabel.setFont(labelFont);

gbc.gridx = 1;
adminPanel.add(idfield, gbc);

// Admin Email Section
gbc.gridx = 0;
gbc.gridy = 2;
JLabel emailLabel = new JLabel("Enter email of the Member:");
emailLabel.setForeground(Color.white);
adminPanel.add(emailLabel, gbc);
gbc.gridx = 1;
emailLabel.setFont(labelFont);

adminPanel.add(adminEmail, gbc);

// Admin Contact Section
gbc.gridx = 0;
gbc.gridy = 3;
JLabel contactLabel = new JLabel("Enter contact number of the Member:");
contactLabel.setForeground(Color.white);
adminPanel.add(contactLabel, gbc);
contactLabel.setFont(labelFont);

gbc.gridx = 1;
adminPanel.add(adminContact, gbc);

// Admin Gender Section
gbc.gridx = 0;
gbc.gridy = 4;
JLabel genderLabel = new JLabel("Enter gender of the Member:");
genderLabel.setForeground(Color.white);
adminPanel.add(genderLabel, gbc);
genderLabel.setFont(labelFont);

gbc.gridx = 1;
adminPanel.add(adminRole, gbc);

// Trainer Name Section
gbc.gridx = 0;
gbc.gridy = 5; 
JLabel trainerNameLabel = new JLabel("Enter name of the trainer:");
trainerNameLabel.setForeground(Color.white);
adminPanel.add(trainerNameLabel, gbc);
gbc.gridx = 1;
trainerNameLabel.setFont(labelFont);

adminPanel.add(trname, gbc);

// Trainer Email Section
gbc.gridx = 0;
gbc.gridy = 6;
JLabel trainerEmailLabel = new JLabel("Enter email of the trainer:");
trainerEmailLabel.setForeground(Color.white);
adminPanel.add(trainerEmailLabel, gbc);
gbc.gridx = 1;
trainerEmailLabel.setFont(labelFont);
adminPanel.add(trEmail, gbc);

// Trainer Contact Section
gbc.gridx = 0;
gbc.gridy = 7;
JLabel trainerContactLabel = new JLabel("Enter contact number of the trainer:");
trainerContactLabel.setForeground(Color.white);
adminPanel.add(trainerContactLabel, gbc);
gbc.gridx = 1;
trainerContactLabel.setFont(labelFont);
adminPanel.add(trContact, gbc);

// Trainer Specialization Section
gbc.gridx = 0;
gbc.gridy = 8;
JLabel trainerSpecializationLabel = new JLabel("Enter specialization of the trainer:");
trainerSpecializationLabel.setForeground(Color.white);
adminPanel.add(trainerSpecializationLabel, gbc);
gbc.gridx = 1;
trainerSpecializationLabel.setFont(labelFont);
adminPanel.add(trgender, gbc);


        // Buttons Section (Add Member, Add Trainer, Remove Trainer)
        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false);
        buttonPanel.add(jmembadd);
        buttonPanel.add(jtraineradd);
        buttonPanel.add(jtrainerdel);
        buttonPanel.add(avlblmember);
        adminPanel.add(buttonPanel, gbc);
         
    
            adminName.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == adminName) {
                        System.out.println("Member Name is: " + adminName.getText());
                    }
                }
            });
            idfield.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == idfield) {
                        System.out.println("member id is : " + idfield.getText());
                    }
                }
            });
            adminEmail.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == adminEmail) {
                        System.out.println("Member Email is: " + adminEmail.getText());
                    }
                }
            });
    
            adminContact.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == adminContact) {
                        System.out.println("Member Contact is: " + adminContact.getText());
                    }
                }
            });
    
            adminRole.addActionListener(new ActionListener()
            { public void actionPerformed(ActionEvent e){
                if(e.getSource()==adminRole){
                    System.out.println("Member gender is :"+adminRole.getSelectedItem());
                } }
            } );
            trEmail.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == trEmail) {
                        System.out.println("Member Name is: " + trEmail.getText());
                    }
                }
            });
            trContact.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == trContact) {
                        System.out.println("Member Name is: " + trContact.getText());
                    }
                }
            });
            trgender.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == trgender) {
                        System.out.println("Trainer is specialized in : " + trgender.getSelectedItem());
                    }
                }
            });
            trname.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource() == trname) {
                        System.out.println("Trainer Name is: " + trname.getText());
                    }
                }
            });
           // JPanel mainadmin = new JPanel(new FlowLayout(FlowLayout.CENTER,5, 5));
            jtraineradd.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e)
             {
                // Get the input values
                String trainerName = trname.getText();
                String trainerEmail = trEmail.getText();
                String trainerContact = trContact.getText();
                String trainermaster = (String) trgender.getSelectedItem();
    
                // Validate the inputs
                if (trainerName.isEmpty() || trainerEmail.isEmpty() || trainerContact.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all trainer fields!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                Trainer t1 = new Trainer();
                t1.setTrainerName(trainerName);
                t1.setTrainerEmail(trainerEmail);
                t1.setTrainermaster(trainermaster);
                t1.setTrainerContact(trainerContact);
                t1.addtrainer();
    
                // Insert into the database
                try {
                   Trainer.insertTrainerIntoDatabase(trainerName,trainerEmail,trainerContact,trainermaster);
                    JOptionPane.showMessageDialog(null, "Trainer added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);}
                catch (Exception e1) { 
                    e1.printStackTrace();
                }
            }});
                 avlblmember.addActionListener(new ActionListener() {
                public void actionPerformed (ActionEvent e){
                    JFrame mFrame = new  JFrame();
                    mFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    mFrame.setSize(600,400);
                    JPanel memberPanel = Member.showMemberPanel();
                    mFrame.add(memberPanel);
                    mFrame.setVisible(true);
                }
            });
            jtrainerdel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)    
             {
                // Get the trainer's email from the text field
                String trainerEmailToDelete = trEmail.getText();
    
                // Validate the email field
                if (trainerEmailToDelete.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter the trainer's email to delete!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                // Delete the trainer from the database
                try {
                    Trainer.deleteTrainerFromDatabase(trainerEmailToDelete);
                    JOptionPane.showMessageDialog(null, "Trainer deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error deleting trainer: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }});
            jmembadd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)    
             {
                try {
                    // Get the input values
                    String name = adminName.getText();
                    String email = adminEmail.getText();
                    String contact = adminContact.getText();
                    String role = (String) adminRole.getSelectedItem();
                    int memb_id = Integer.parseInt(idfield.getText()); // Correct way to parse an integer
    
                    // Validate the inputs
                    if (name.isEmpty() || email.isEmpty() || contact.isEmpty() || role == null) {
                        JOptionPane.showMessageDialog(null, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
    
                    Member newMember = new Member();
                    //newMember.setId(memb_id);
                    newMember.setName(name);
                    newMember.setContact(contact);
                    newMember.setEmail(email);
    
                    // Display the member details in the terminal
                    newMember.addmember();
                    // Optional: Show confirmation in GUI
                    JOptionPane.showMessageDialog(null, "Member added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);/* */
                    // Insert the member into the database
                   Member.insertMemberIntoDatabase(name, email, contact, role, memb_id);
                }
                catch (Exception ex) {
                    // Handle any exceptions and display an error message
                    JOptionPane.showMessageDialog(null, "Error adding member: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }});
         return adminPanel;
        }
    }