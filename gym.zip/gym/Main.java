import java.util.ArrayList; 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Main implements ActionListener {
    private static JPanel mainPanel;
    private static JFrame jf;
    private static CardLayout cardlayout;
    
    public static void main(String[] args) {
        jf = new JFrame("Gym Management System");
        jf.setSize(600, 600);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // CardLayout and main panel
        cardlayout = new CardLayout();
        mainPanel = new JPanel(cardlayout);
        // Add panels to the CardLayout
        mainPanel.add(createLoginPanel(), "LoginPanel");
        mainPanel.add(createTabbedPane(), "AppPanel");
        jf.add(mainPanel);
        jf.setVisible(true);
    }  

    public static JTabbedPane createTabbedPane() {
        JTabbedPane tabbedPane = new JTabbedPane();

        // Add tabs
        tabbedPane.addTab("Admin", Member.createAdminNTrainerPanel());
        tabbedPane.addTab("Trainer", Trainer.createTrainerPanel());
        tabbedPane.addTab("Membership", Payment.createpaymentPanel());
        tabbedPane.addTab("Schedule", Schedule.crateschedulePanel());
        return tabbedPane;
    }

    public static JPanel createLoginPanel() {
        // Main panel for login
        JPanel mainlogin = new JPanel(new BorderLayout());
        mainlogin.setBackground(new Color(0, 102, 204));  // Background color

        // Create a heading label with enhanced font and color
        JLabel headingLabel = new JLabel("GYM MANAGEMENT SYSTEM");
        headingLabel.setForeground(Color.white); // White text color
        headingLabel.setFont(new Font("Sans Serif", Font.BOLD, 36)); // Font style
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainlogin.add(headingLabel, BorderLayout.NORTH);

        // Panel for login form
        JPanel loginPanel = new JPanel(new GridBagLayout()) {
            @Override
            public void paintComponent(Graphics g) {
                    super.paintComponent(g);
            
                    // Load the background image
                    Image backgroundImage = new ImageIcon(Member.class.getResource("cor.jpg")).getImage();
            
                    // Draw the image to fit the entire panel
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            };
          /* */ 
            loginPanel.setOpaque(false);
              loginPanel.setBackground(Color.black); 

        // GridBagConstraints for precise control over the layout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Adding space between components
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("Arial", Font.BOLD, 25); //

        // Username and password labels
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.white );
        usernameLabel.setFont(labelFont);
        gbc.gridx = 0;
        gbc.gridy = 0;
        loginPanel.add(usernameLabel, gbc);

        // Username field
        JTextField usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 20));
        usernameField.setPreferredSize(new Dimension(200, 40));
        usernameField.setBackground(Color.black);
        usernameField.setForeground(Color.white);

        gbc.gridx = 1;
        gbc.gridy = 0;
        loginPanel.add(usernameField, gbc);

        // Password label
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.white);

        gbc.gridx = 0;
        passwordLabel.setFont(labelFont);

        gbc.gridy = 1;
        loginPanel.add(passwordLabel, gbc);

        // Password field
        JPasswordField passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 20));
        passwordField.setPreferredSize(new Dimension(200, 40));
        passwordField.setForeground(Color.white);     

           passwordField.setBackground(Color.black);
        gbc.gridx = 1;
        gbc.gridy = 1;
        loginPanel.add(passwordField, gbc);

        // Button panel with Login and Cancel buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false); // Transparent panel

        JButton loginButton = new JButton("Login");
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(0, 153, 51));  // Green color for login
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setPreferredSize(new Dimension(100, 40));

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setBackground(new Color(255, 51, 51));  // Red color for cancel
        cancelButton.setFont(new Font("Arial", Font.BOLD, 16));
        cancelButton.setPreferredSize(new Dimension(100, 40));

        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);
        // Style buttons
        loginButton.setForeground(Color.black);
        loginButton.setBackground(Color.white);
        cancelButton.setForeground(Color.black);
        cancelButton.setBackground(Color.white);

        // Add loginPanel and buttonPanel to mainlogin
        mainlogin.add(loginPanel, BorderLayout.CENTER); // Add login form to the center
        mainlogin.add(buttonPanel, BorderLayout.SOUTH); 
      
        // Login button action listener
       loginButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e)    
         {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            // Simple hardcoded validation (replace with database validation)
            if (username.equals("ashhad") && password.equals("ashhad123")) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                cardlayout.show(mainPanel, "AppPanel"); // Switch to the application panel
            }
            else if (username.equals("uzair") && password.equals("uzair123")) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                cardlayout.show(mainPanel, "AppPanel"); }
            else{
                JOptionPane.showMessageDialog(null, "Invalid username or password!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }});
        // Cancel button action listener
        cancelButton.addActionListener(e -> System.exit(0));
        return mainlogin;
    }
 }    

  
