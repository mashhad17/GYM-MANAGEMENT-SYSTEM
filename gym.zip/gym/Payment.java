import java.util.ArrayList; 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*; 
import java.awt.event.*; 
import java.sql.*;
                       
public class Payment {
    private double amount;
    private String paymentDate;
    private String status;
    private Member member;
    
    public Payment(double amount,String paymentDate,String status,String name) {
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.status = "Pending";
        this.member = new Member();
        this.member.setName(name);
    }
    public void setMember(Member member){
        this.member=member;
    } 
    public Member getMember() {
         return member; 
        }

       public void assignMember(Member member) {
        this.member = member;
    }
    
    // Getters and setters
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) { this.paymentDate = paymentDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
 
    public void displayPayment(){
        System.out.println("Payment Date is : "+paymentDate);
        System.out.println("Payment amount is :"+amount);
        System.out.println("Payment status is :"+status);
        System.out.println("Member details:");
        member.addmember();
    }
     public static JPanel showPaymentPanel() {
    JPanel paymenntPanel = new JPanel(new BorderLayout());
    paymenntPanel.setBackground(Color.LIGHT_GRAY);
    String[] columnNames = { "Pay_id","Fees", "Payment Date","Status","MEMBER Id"};
    DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
    JTable paymentTable = new JTable(tableModel);

    // Add table header and table to the panel
    paymenntPanel.add(new JScrollPane(paymentTable), BorderLayout.CENTER);

    try {
        //Database connection and query
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
        String query = "SELECT * FROM Payment";
        PreparedStatement pst = con.prepareStatement(query);
        ResultSet rs = pst.executeQuery();
        // Populate table with data from the database
        while (rs.next()) {
        int payment_id = rs.getInt("payment_id");
        String amount= rs.getString("amount");
        String payment_date = rs.getString("payment_date");
        String status = rs.getString("status");
        int member_id= rs.getInt("member_id");
        tableModel.addRow(new Object[]{payment_id,amount,payment_date,status,member_id});
      }

      // Close database resources
      rs.close();
      pst.close();
      con.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(paymenntPanel, "Error loading schedule data.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    return paymenntPanel;
}
     public static void insertPaymentToDatabase(int memberId, String memberName, double amount, String paymentDate, String status) {
                // Database credentials
                String url = "jdbc:mysql://localhost:3306/test_schema?useSSL=false"; // Update your database name
                String username = "root"; // Update your database username
                String password = "1214"; // Update your database password
        
                // SQL query to insert payment record
                String sql = "INSERT INTO Payment (amount, payment_date, status, member_id) VALUES (?, ?, ?, ?)";
        
                try (Connection conn = DriverManager.getConnection(url, username, password);
                     PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
                    // Set the parameters for the SQL query
                    pstmt.setDouble(1, amount);
                    pstmt.setString(2, paymentDate);
                    pstmt.setString(3, status);
                    pstmt.setInt(4, memberId);
        
                    // Execute the query and check if it was successful
                    int rowsInserted = pstmt.executeUpdate();
        
                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Payment record added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to add payment record!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception e) {
                    e.printStackTrace(); // Log the exception
                    JOptionPane.showMessageDialog(null, "Error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
    public static void deletePaymentFromDatabase(int memb_id) throws  Exception{
        String url = "jdbc:mysql://localhost:3306/test_schema?useSSL=false"; // Update your database name
        String username = "root"; // Update your database username
        String password = "1214"; 
        // Update your database password
        
        String sqlDelete = "DELETE FROM payment WHERE member_id = ?";
        try (Connection conn = DriverManager.getConnection(url, username, password);
        PreparedStatement pstmt = conn.prepareStatement(sqlDelete)) {
            pstmt.setInt(1, memb_id);
        
            // Execute the delete query
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                System.out.println("Payment record with ID " + memb_id + " deleted successfully.");
            } else {
                System.out.println("No payment record found with ID " + memb_id+ ".");
            }
            
        } catch (SQLException e) {
            System.out.println("Error occurred while deleting payment record: " + e.getMessage());
        } 
   }      
    public static JPanel createpaymentPanel(){
        String[] paid = {"Paid", "Not Paid", "Pending"};
        // Create the panel with GridBagLayout for better control over positioning
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);  // Add space between components
        gbc.anchor = GridBagConstraints.WEST;
        Font labelFont = new Font("Arial", Font.BOLD, 25); //

        // Components for Payment Panel
      
        JTextField amount = new JTextField(20);
        amount.setBackground(Color.black);
        amount.setForeground(Color.white);
        amount.setFont(new Font("Arial", Font.PLAIN, 20));

        JTextField date = new JTextField(20);
        date.setBackground(Color.black);
        date.setForeground(Color.white);
        date.setFont(new Font("Arial", Font.PLAIN, 20));

        JComboBox<String> status = new JComboBox<>(paid);
        status.setBackground(Color.black);
        status.setForeground(Color.white);
        status.setFont(new Font("Arial", Font.PLAIN, 20));
        JLabel membDropdownLabel = new JLabel("Select a Member from the database:");
        membDropdownLabel.setForeground(Color.white);
        membDropdownLabel.setFont(labelFont);
        JComboBox<String> membDropdown = new JComboBox<>();
membDropdown.setFont(new Font("Arial", Font.PLAIN, 20));
membDropdown.setBackground(Color.black);
membDropdown.setForeground(Color.white);


        JButton record = new JButton("Add to payment history");
        JButton delrecords = new JButton("Clear records");
        JButton payButton = new JButton("Payment history");

        // Style buttons
        record.setForeground(Color.white);
        record.setBackground(Color.black);  // Green color for "Add to payment history"
        record.setFont(new Font("Arial", Font.BOLD, 20));

        delrecords.setForeground(Color.white);
        delrecords.setBackground(Color.black);  // Red color for "Clear records"
        delrecords.setFont(new Font("Arial", Font.BOLD, 20));

        payButton.setForeground(Color.white);
        payButton.setBackground(Color.black);  // Blue color for "Payment history"
        payButton.setFont(new Font("Arial", Font.BOLD, 20));
        JPanel paypanel = new JPanel(new GridBagLayout()) {
            @Override
            public void paintComponent(Graphics g) {
                    super.paintComponent(g);
            
                    // Load the background image
                    Image backgroundImage = new ImageIcon(Member.class.getResource("room.jpg")).getImage();
            
                    // Draw the image to fit the entire panel
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            };
          /* */ 
            paypanel.setOpaque(false);
              paypanel.setBackground(new Color(255, 218, 185)); 

              // Add components to the panel with proper alignment using GridBagLayout
         // Layout for Components
         paypanel.add(membDropdownLabel);

         gbc.gridx = 0;
    gbc.gridy = 0;
    paypanel.add(membDropdown, gbc);

    gbc.gridx = 1;
    paypanel.add(membDropdown, gbc);

    gbc.gridx = 0;
    gbc.gridy = 1;
    JLabel amountLabel = new JLabel("Enter the amount that member paid:");
    amountLabel.setForeground(Color.white);
    amountLabel.setFont(labelFont);
    paypanel.add(amountLabel, gbc);

    gbc.gridx = 1;
    paypanel.add(amount, gbc);

    gbc.gridx = 0;
    gbc.gridy = 2;
    JLabel dateLabel = new JLabel("Enter the date the fees were paid:");
    dateLabel.setForeground(Color.white);
    dateLabel.setFont(labelFont);
    paypanel.add(dateLabel, gbc);

    gbc.gridx = 1;
    paypanel.add(date, gbc);

    gbc.gridx = 0;
    gbc.gridy = 3;
    JLabel statusLabel = new JLabel("Enter the status of the fees:");
    statusLabel.setForeground(Color.WHITE);
    statusLabel.setFont(labelFont);
    paypanel.add(statusLabel, gbc);

    gbc.gridx = 1;
    paypanel.add(status, gbc);

    // Buttons
    gbc.gridx = 0;
    gbc.gridy = 4;
    gbc.gridwidth = 2;
    JPanel buttonPanel = new JPanel(new FlowLayout());
    buttonPanel.setOpaque(false);
    buttonPanel.add(record);
    buttonPanel.add(delrecords);
    buttonPanel.add(payButton);
    paypanel.add(buttonPanel, gbc);


      
// Populate the trainer dropdown with data from the database
try {
    // Database connection
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test_schema", "root", "1214");
    String query = "SELECT memb_id, name, email FROM members"; // Replace with your table and column names
    PreparedStatement pst = con.prepareStatement(query);
    ResultSet rs = pst.executeQuery();
    // Populate the dropdown
    while (rs.next()) {
        int  memb_id = rs.getInt("memb_id");
         String memb_name = rs.getString("name");
        String email = rs.getString("email");
        membDropdown.addItem(memb_id+ " | " + memb_name + " | " + email);
    }

    // Close resources
    rs.close();
    pst.close();
    con.close();
} catch (SQLException ex) {
    ex.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error fetching trainers from the database: " + ex.getMessage());
}


      
    
        status.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e){
            if(e.getSource()==status){
                System.out.println(" Fees status is  :"+status.getSelectedItem());
            } }
        } );
      
        // Add ActionListener for 'amount' JTextField
        amount.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the text entered in the amount field and print it
                String enteredAmount = amount.getText();
                System.out.println("Amount entered: " + enteredAmount);
            }
        }
);
payButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e){
     // Create a new JFrame to display the schedule
     JFrame payFrame = new JFrame("Available Schedules");
     payFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
     payFrame.setSize(600, 400);

     // Get the schedule panel and add it to the JFrame
     JPanel paymenntPanel = Payment.showPaymentPanel();
     payFrame.add(paymenntPanel);

     // Set the frame's location to the center of the screen and make it visible
    payFrame.setLocationRelativeTo(null);
     payFrame.setVisible(true);
 }
});
record.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
            String selectedMember = (String) membDropdown.getSelectedItem();
            String amountStr = amount.getText();
            String paymentDate = date.getText();
            String paymentStatus = (String) status.getSelectedItem();

            if (selectedMember == null || amountStr.isEmpty() || paymentDate.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String[] memberDetails = selectedMember.split("\\|");
            int memberId = Integer.parseInt(memberDetails[0].trim());
            String memberName = memberDetails[1].trim();
            double paymentAmount = Double.parseDouble(amountStr);

            Payment.insertPaymentToDatabase(memberId, memberName, paymentAmount, paymentDate, paymentStatus);

            JOptionPane.showMessageDialog(null, "Payment details added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid number format for amount!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});
delrecords.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Retrieve the selected member from the dropdown
        String selectedMember = (String) membDropdown.getSelectedItem();

        if (selectedMember == null || selectedMember.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a member to delete the payment record.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Extract the member ID from the selected item
            String[] memberDetails = selectedMember.split("\\|");
            int memberId = Integer.parseInt(memberDetails[0].trim());

            // Call the method to delete the payment from the database
            Payment.deletePaymentFromDatabase(memberId);

            // Show success message
            JOptionPane.showMessageDialog(null, "Payment record deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid member ID format!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
});                   
        // Add ActionListener for 'date' JTextField
        date.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the text entered in the date field and print it
                String enteredDate = date.getText();
                System.out.println("Date entered: " + enteredDate);
            }
        });
        return paypanel;
    }    
}